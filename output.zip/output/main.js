"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
let timer = 256;
const tickRate = 16;
const visualRate = 256;
var Crop;
(function (Crop) {
    Crop[Crop["Wheat"] = 0] = "Wheat";
    Crop[Crop["Barley"] = 1] = "Barley";
    Crop[Crop["Rye"] = 2] = "Rye";
})(Crop || (Crop = {}));
var Store;
(function (Store) {
    Store[Store["WheatFarm"] = 0] = "WheatFarm";
    Store[Store["BarleyFarm"] = 1] = "BarleyFarm";
    Store[Store["Person"] = 2] = "Person";
})(Store || (Store = {}));
const crops = [Crop.Wheat, Crop.Barley, Crop.Rye];
const baseCropGrowthRate = 0.5;
const clickGrowthRate = 1;
const cropGrowthRate = new Map();
crops.forEach(crop => cropGrowthRate.set(crop, baseCropGrowthRate));
const cropMarket = new Map([
    [Crop.Wheat, 3],
    [Crop.Barley, 2],
    [Crop.Rye, 1],
]);
const storeToCrop = new Map([
    [Store.BarleyFarm, Crop.Barley],
    [Store.WheatFarm, Crop.Wheat]
]);
const storePrices = new Map([
    [Store.BarleyFarm, 100],
    [Store.WheatFarm, 1000],
    [Store.Person, 10]
]);
var PersonType;
(function (PersonType) {
    PersonType[PersonType["Farmer"] = 0] = "Farmer";
    PersonType[PersonType["Soldier"] = 1] = "Soldier";
})(PersonType || (PersonType = {}));
const consumptionRate = 0.1;
class Farm {
    constructor(stockpile, totalFarmers = 0) {
        this.stockpile = stockpile;
        this.totalFarmers = totalFarmers;
        console.assert(this.stockpile > 0, "Stockpile is empty");
        console.assert(this.totalFarmers >= 0, "Negative farmers?");
    }
    harvest(crop) {
        var _a;
        const amountGrown = Math.min(this.totalFarmers, this.stockpile);
        if (this.stockpile - this.totalFarmers * consumptionRate > 0) {
            const growthRate = (_a = cropGrowthRate.get(crop)) !== null && _a !== void 0 ? _a : baseCropGrowthRate;
            this.stockpile += amountGrown * growthRate;
            this.stockpile -= this.totalFarmers * consumptionRate;
            this.stockpile = Math.ceil(this.stockpile);
        }
    }
    playerHarvest(crop) {
        this.stockpile += Math.ceil(clickGrowthRate * (1 + this.totalFarmers));
    }
}
const lootMinimum = 0.75;
const lootMaximum = 1.25;
class Army {
    constructor() {
        this.totalSoldiers = 0;
    }
    attack(opponent) {
        if (this.totalSoldiers * randFloat(lootMinimum, lootMaximum) < opponent.strength)
            return null;
        const lootFarms = new Map();
        opponent.farms.forEach((farm, crop) => {
            lootFarms.set(crop, new Farm(farm.stockpile * lootMinimum, Math.ceil(farm.totalFarmers * lootMinimum)));
        });
        return {
            gold: opponent.gold - this.totalSoldiers,
            idlePopulation: Math.ceil(opponent.idlePopulation * lootMinimum),
            farms: lootFarms,
        };
    }
}
function randInt(min, max) {
    console.assert(Number.isInteger(min) && Number.isInteger(max), "randInt should not use non-integer inputs");
    return Math.floor(Math.random() * (max - min + 1) + min);
}
function randFloat(min, max) {
    return Math.random() * (max - min) + min;
}
const minLoss = 0.3;
const maxLoss = 0.75;
class Kingdom {
    constructor(name, idlePopulation) {
        this.name = name;
        this.idlePopulation = idlePopulation;
        this.gold = 0;
        this.army = new Army();
        this.farms = new Map();
    }
    attack(opponent) {
        const waitTime = (opponent.strength + this.army.totalSoldiers) / 300;
        window.setTimeout(() => {
            const result = this.army.attack(opponent);
            if (result == null) {
                alert(`The attack against ${opponent.name} failed.`);
                player.army.totalSoldiers = Math.ceil(player.army.totalSoldiers * randFloat(minLoss, maxLoss));
                player.idlePopulation = Math.ceil(player.idlePopulation * randFloat(minLoss, maxLoss));
                player.gold = Math.ceil(player.gold * randFloat(minLoss, maxLoss));
                player.farms.forEach((farm, crop) => {
                    const playerFarm = player === null || player === void 0 ? void 0 : player.farms.get(crop);
                    if (playerFarm != null) {
                        farm.totalFarmers = Math.ceil((playerFarm === null || playerFarm === void 0 ? void 0 : playerFarm.totalFarmers) * randFloat(minLoss, maxLoss));
                        farm.stockpile = Math.ceil((playerFarm === null || playerFarm === void 0 ? void 0 : playerFarm.stockpile) * randFloat(minLoss, maxLoss));
                    }
                });
            }
            else {
                alert(`The attack against ${opponent.name} succeded.`);
                this.gold += result.gold;
                this.idlePopulation += result.idlePopulation;
                this.farms.forEach((farm, crop) => {
                    const lootedFarm = result === null || result === void 0 ? void 0 : result.farms.get(crop);
                    if (lootedFarm != null) {
                        farm.totalFarmers += lootedFarm === null || lootedFarm === void 0 ? void 0 : lootedFarm.totalFarmers;
                        farm.stockpile += lootedFarm === null || lootedFarm === void 0 ? void 0 : lootedFarm.stockpile;
                    }
                });
                kingdoms.pop();
                kingdoms[kingdoms.length - 1].army.totalSoldiers =
                    (player.idlePopulation + player.army.totalSoldiers) * 2;
                setIdInnerHTML("enemy-kingdom-name", kingdoms[kingdoms.length - 1].name);
            }
        }, waitTime);
    }
    orderHarvest() {
        this.farms.forEach((farm, crop) => farm.harvest(crop));
    }
    buyCrop(crop, amt) {
        const cost = amt * cropMarket.get(crop);
        if (cost > this.gold)
            return;
        const farm = this.farms.get(crop);
        this.gold -= cost;
        farm.stockpile += amt;
    }
    sellCrop(crop, amt) {
        const farm = this.farms.get(crop);
        if (farm.stockpile < amt)
            return;
        const profit = amt * cropMarket.get(crop);
        farm.stockpile -= amt;
        this.gold += profit;
    }
    get strength() {
        return this.idlePopulation * 0.25 + this.army.totalSoldiers;
    }
}
const kingdomNames = ["Kingdom of the North", "Westros", "Iron Islands", "Mountian and the Vale", "Isles and Rivers", "The Stormlands", "Kingdom of the Reach", "Principality of Dorne"];
const minStartingRye = 50;
const maxStartingRye = 100;
const minStartingPop = 4;
const maxStartingPop = 10;
const baseEnemyPop = 10;
const baseLootGold = 100;
const currentKingdom = 1;
const kingdoms = [
    new Kingdom(promptPlayer("Enter the name of your kingdom"), randInt(minStartingPop, maxStartingPop))
];
kingdomNames.forEach((name) => {
    const kingdom = new Kingdom(name, baseEnemyPop);
    kingdom.gold = baseLootGold;
    kingdoms.push(kingdom);
});
const player = kingdoms[0];
player.farms.set(Crop.Rye, new Farm(randInt(minStartingRye, maxStartingRye)));
let sellAmount = "1";
function promptPlayer(message) {
    let result = null;
    while (result == null)
        result = window.prompt(message, "");
    return result;
}
function setElementInnerHTML(el, content) {
    el.innerHTML = content.toString();
}
function setIdInnerHTML(id, content) {
    setElementInnerHTML(document.getElementById(id), content);
}
function percise(num, sig) {
    return Number(num.toFixed(sig));
}
function handleSellAmount(el) {
    for (const child of document.getElementsByClassName("radio-group")) {
        if (child != null)
            if (child.children[0].checked)
                sellAmount = child.children[1].innerHTML;
    }
}
function onAttack() {
    return __awaiter(this, void 0, void 0, function* () {
        if (player.name !== kingdoms[kingdoms.length - 1].name)
            player.attack(kingdoms[kingdoms.length - 1]);
    });
}
function handleSell(crop) {
    if (player.farms.get(crop).stockpile >= parseInt(sellAmount)) {
        player.farms.get(crop).stockpile -= parseInt(sellAmount);
        player.gold += parseInt(sellAmount) * cropMarket.get(crop);
    }
}
function handleBuy(storeItem, id) {
    const buyFarm = (crop) => {
        var _a;
        player.farms.set(crop, new Farm(1));
        const stats = document.getElementById("gold-grain-stats");
        const grainStat = document.createElement("p");
        grainStat.id = Crop[crop] + "-stats";
        setElementInnerHTML(grainStat, player.farms.get(crop).stockpile.toString() + " " + Crop[crop]);
        stats === null || stats === void 0 ? void 0 : stats.appendChild(grainStat);
        const sellTab = document.getElementById("sell-options");
        const newCrop = document.createElement("button");
        newCrop.className = "btn";
        newCrop.id = Crop[crop] + "-sell-option";
        setElementInnerHTML(newCrop, Crop[crop]);
        newCrop.onclick = () => handleSell(crop);
        sellTab === null || sellTab === void 0 ? void 0 : sellTab.appendChild(newCrop);
        (_a = document.getElementById(id)) === null || _a === void 0 ? void 0 : _a.remove();
        if (player.farms.size == 3) {
            alert("An enemy kingdom is attacking " + player.name);
            setIdInnerHTML("enemy-kingdom-name", kingdoms[kingdoms.length - 1].name);
            document.getElementById("war").style.display = "flex";
            document.getElementById("assignment-container-soldier").style.display = "flex";
        }
    };
    const buyPerson = () => {
        player.idlePopulation += 1;
    };
    if (player.gold >= storePrices.get(storeItem)) {
        switch (storeItem) {
            case Store.BarleyFarm:
                buyFarm(Crop.Barley);
                break;
            case Store.WheatFarm:
                buyFarm(Crop.Wheat);
                break;
            case Store.Person:
                buyPerson();
                break;
            default:
                break;
        }
        player.gold -= storePrices.get(storeItem);
    }
}
function personAssignment() {
    var _a, _b;
    crops.map((value) => {
        var _a, _b, _c;
        const parent = document.createElement("div");
        parent.id = "assignment-container-" + Crop[value];
        parent.className = "assignment-container";
        (_a = document.getElementById("farmer")) === null || _a === void 0 ? void 0 : _a.appendChild(parent);
        const farmers = document.createElement("span");
        farmers.id = "farmers-" + Crop[value];
        farmers.className = "total-farmers";
        setElementInnerHTML(farmers, (_c = (_b = player.farms.get(value)) === null || _b === void 0 ? void 0 : _b.totalFarmers) !== null && _c !== void 0 ? _c : 0);
        parent.appendChild(farmers);
        const farmerType = document.createElement("span");
        farmerType.id = "farmer-type-" + Crop[value];
        farmerType.className = "type";
        setElementInnerHTML(farmerType, "  " + Crop[value] + " Farmers ");
        parent.appendChild(farmerType);
        const assignButton = document.createElement("button");
        assignButton.className = "btn a-btn";
        setElementInnerHTML(assignButton, "+");
        assignButton.onclick = () => handleAssignPerson(PersonType.Farmer, value);
        parent.appendChild(assignButton);
        const removeButton = document.createElement("button");
        removeButton.className = "btn a-btn";
        removeButton.onclick = () => handleRemovePerson(PersonType.Farmer, value);
        setElementInnerHTML(removeButton, "-");
        parent.appendChild(removeButton);
    });
    const parent = document.createElement("div");
    parent.id = "assignment-container-soldier";
    parent.style.display = "none";
    parent.className = "assignment-container";
    (_a = document.getElementById("farmer")) === null || _a === void 0 ? void 0 : _a.appendChild(parent);
    const soldiers = document.createElement("span");
    soldiers.id = "assignment-soldier";
    soldiers.className = "total-farmers";
    setElementInnerHTML(soldiers, (_b = player.army.totalSoldiers) !== null && _b !== void 0 ? _b : 0);
    parent.appendChild(soldiers);
    const soldierText = document.createElement("span");
    soldierText.id = "soldier-text";
    soldierText.className = "type";
    setElementInnerHTML(soldierText, " Soldiers");
    parent.appendChild(soldierText);
    const assignButton = document.createElement("button");
    assignButton.className = "btn a-btn";
    setElementInnerHTML(assignButton, "+");
    assignButton.onclick = () => handleAssignPerson(PersonType.Soldier, undefined);
    parent.appendChild(assignButton);
    const removeButton = document.createElement("button");
    removeButton.className = "btn a-btn";
    removeButton.onclick = () => handleRemovePerson(PersonType.Soldier, undefined);
    setElementInnerHTML(removeButton, "-");
    parent.appendChild(removeButton);
}
function loadGUI() {
    storePrices.forEach((price, storeItem) => {
        var _a;
        const store = document.getElementById("store-tab");
        const button = document.createElement("button");
        button.id = Store[storeItem] + "-store";
        button.onclick = () => handleBuy(storeItem, Store[storeItem] + "-store");
        button.className = "btn";
        setElementInnerHTML(button, ((_a = Crop[storeToCrop.get(storeItem)]) !== null && _a !== void 0 ? _a : Store[storeItem])
            + " " + storePrices.get(storeItem) + " Gold");
        store === null || store === void 0 ? void 0 : store.appendChild(button);
    });
    setIdInnerHTML("gold", player.gold.toString());
    player.farms.forEach((value, key) => {
        const parent = document.getElementById("gold-grain-stats");
        const grain = document.createElement("p");
        grain.id = Crop[key] + "-stats";
        setElementInnerHTML(grain, value.stockpile + " " + Crop[key]);
        parent.appendChild(grain);
        const sellOptions = document.getElementById("sell-options");
        const sellOption = document.createElement("button");
        sellOption.innerHTML = Crop[key];
        sellOption.className = "btn";
        sellOption.onclick = () => handleSell(key);
        sellOption.id = Crop[key] + "-sell-option";
        sellOptions.appendChild(sellOption);
    });
    setIdInnerHTML("people", player.idlePopulation.toString());
    setIdInnerHTML("soldiers", player.army.totalSoldiers.toString());
    setIdInnerHTML("enemy-kingdom-name", kingdomNames[kingdomNames.length - 1]);
    console.log(kingdomNames[kingdomNames.length - 1]);
    personAssignment();
}
function updateStats() {
    var _a;
    setIdInnerHTML("gold", player.gold.toString());
    setIdInnerHTML("people", player.idlePopulation.toString());
    player.farms.forEach((value, key) => {
        setIdInnerHTML(Crop[key] + "-stats", value.stockpile.toString() + " " + Crop[key]);
    });
    crops.map((value) => {
        var _a, _b;
        setIdInnerHTML("farmers-" + Crop[value], (_b = (_a = player.farms.get(value)) === null || _a === void 0 ? void 0 : _a.totalFarmers) !== null && _b !== void 0 ? _b : 0);
    });
    setIdInnerHTML("assignment-soldier", ((_a = player.army.totalSoldiers) !== null && _a !== void 0 ? _a : 0));
    if (player.farms.size > 0)
        player.orderHarvest();
}
function handleHarvest() {
    player.farms.forEach((value, key) => value.playerHarvest(key));
}
function handleAssignPerson(type, crop) {
    if (type == PersonType.Farmer) {
        if (player.farms.get(crop) != null && player.idlePopulation > 0) {
            player.idlePopulation--;
            player.farms.get(crop).totalFarmers++;
        }
    }
    else if (type == PersonType.Soldier)
        if (player.idlePopulation > 0) {
            player.army.totalSoldiers++;
            player.idlePopulation--;
        }
}
function handleRemovePerson(type, crop) {
    console.log(player.army.totalSoldiers);
    if (type == PersonType.Farmer) {
        if (player.farms.get(crop).totalFarmers > 0) {
            player.farms.get(crop).totalFarmers--;
            player.idlePopulation++;
        }
    }
    else if (type == PersonType.Soldier)
        if (player.army.totalSoldiers > 0) {
            player.army.totalSoldiers--;
            player.idlePopulation++;
        }
}
window.onload = () => {
    window.setInterval(() => {
        timer += tickRate;
        if (timer > visualRate) {
            timer -= visualRate;
            updateStats();
        }
    }, tickRate);
    loadGUI();
};
