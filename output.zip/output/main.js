"use strict";
let timer = 256;
const tickRate = 16;
const visualRate = 256;
var Crop;
(function (Crop) {
    Crop[Crop["Wheat"] = 0] = "Wheat";
    Crop[Crop["Barley"] = 1] = "Barley";
    Crop[Crop["Rye"] = 2] = "Rye";
})(Crop || (Crop = {}));
var Store;
(function (Store) {
    Store[Store["WheatFarm"] = 0] = "WheatFarm";
    Store[Store["BarleyFarm"] = 1] = "BarleyFarm";
    Store[Store["Person"] = 2] = "Person";
})(Store || (Store = {}));
const crops = [Crop.Wheat, Crop.Barley, Crop.Rye];
const baseCropGrowthRate = 0.1;
const clickGrowthRate = 0.5;
const cropGrowthRate = new Map();
crops.forEach(crop => cropGrowthRate.set(crop, baseCropGrowthRate));
const cropMarket = new Map([
    [Crop.Wheat, 3],
    [Crop.Barley, 2],
    [Crop.Rye, 1],
]);
const farmPrices = new Map([
    [Crop.Barley, 100],
    [Crop.Wheat, 1000]
]);
const consumptionRate = 0.07;
class Farm {
    constructor(initalSeed) {
        this.totalFarmers = 0;
        this.stockpile = initalSeed;
        console.assert(this.stockpile > 0);
    }
    harvest(crop) {
        const amountGrown = Math.min(this.totalFarmers, this.stockpile);
        if (this.stockpile - this.totalFarmers * consumptionRate > 0) {
            this.stockpile += amountGrown * cropGrowthRate.get(crop);
            this.stockpile -= this.totalFarmers * consumptionRate;
            this.stockpile = Math.ceil(this.stockpile);
        }
        console.assert(this.stockpile > 0);
    }
    playerHarvest(crop) {
        this.stockpile += clickGrowthRate * (1 + this.totalFarmers);
        this.stockpile = Math.ceil(this.stockpile);
    }
}
const baseDPSPerSoldier = 1;
class Army {
    constructor() {
        this.totalSoldiers = 0;
        this.dpsPerSoldier = baseDPSPerSoldier;
    }
    attack(kingdom) {
        console.assert(false, "Attacking a Kingdom is not implemented");
        return kingdom;
    }
}
function getRandInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
const startingHealth = 100;
class Kingdom {
    constructor(name, idlePopulation) {
        this.health = startingHealth;
        this.gold = 0;
        this.army = new Army();
        this.farms = new Map();
        this.idlePopulation = idlePopulation;
        this.name = name;
    }
    orderHarvest() {
        var _a;
        console.log((_a = this.farms) === null || _a === void 0 ? void 0 : _a.size);
        this.farms.forEach((farm, crop) => farm.harvest(crop));
    }
    buyCrop(crop, amt) {
        const cost = amt * cropMarket.get(crop);
        if (cost > this.gold)
            return;
        const farm = this.farms.get(crop);
        this.gold -= cost;
        farm.stockpile += amt;
    }
    sellCrop(crop, amt) {
        const farm = this.farms.get(crop);
        if (farm.stockpile < amt)
            return;
        const profit = amt * cropMarket.get(crop);
        farm.stockpile -= amt;
        this.gold += profit;
    }
}
const minStartingRye = 50;
const maxStartingRye = 100;
const kingdoms = [
    new Kingdom(promptPlayer("Enter the name of your kingdom"), getRandInt(4, 10)),
];
const player = kingdoms[0];
player.farms.set(Crop.Rye, new Farm(getRandInt(minStartingRye, maxStartingRye)));
let selectedFarm = "Rye";
function promptPlayer(message) {
    let result = null;
    while (result == null)
        result = window.prompt(message, "");
    return result;
}
function setElementInnerHTML(el, content) {
    el.innerHTML = content.toString();
}
function setIdInnerHTML(id, content) {
    setElementInnerHTML(document.getElementById(id), content);
}
function percise(num, sig) {
    return Number(num.toFixed(sig));
}
function handleBuy(ev) {
    const element = ev.target;
    const name = element.id;
    const key = name.substring(0, name.indexOf("-"));
    const crop = Crop[key];
    if (player.gold >= farmPrices.get(crop)) {
        if (crop !== null || crop !== undefined) {
            if (!player.farms.has(crop)) {
                player.farms.set(crop, new Farm(1));
                const stats = document.getElementById("gold-grain-stats");
                const grainStat = document.createElement("p");
                grainStat.id = Crop[crop] + "-stats";
                setElementInnerHTML(grainStat, player.farms.get(crop).stockpile.toString() + " " + Crop[crop]);
                const farms = document.getElementById("farms");
                const farmOption = document.createElement("option");
                farmOption.id = Crop[crop] + "-farm-option";
                setElementInnerHTML(farmOption, Crop[crop]);
                farms.appendChild(farmOption);
                const sellCrops = document.getElementById("crops-sale");
                const cropOption = document.createElement("option");
                cropOption.id = Crop[crop] + "-crop-option";
                setElementInnerHTML(cropOption, Crop[crop]);
                sellCrops.appendChild(cropOption);
                stats === null || stats === void 0 ? void 0 : stats.appendChild(grainStat);
            }
        }
        player.gold -= farmPrices.get(crop);
        document.getElementById(name).style.display = "none";
    }
}
function loadGUI() {
    const store = document.getElementById("store-tab");
    cropMarket.forEach((value, key) => {
        if (key != Crop.Rye) {
            const button = document.createElement("button");
            button.onclick = handleBuy;
            button.id = Crop[key] + "-store";
            button.className = "btn";
            setElementInnerHTML(button, Crop[key] + " " + farmPrices.get(key) + "G");
            store === null || store === void 0 ? void 0 : store.appendChild(button);
        }
    });
    setIdInnerHTML("gold", player.gold.toString());
    player.farms.forEach((value, key) => {
        const parent = document.getElementById("gold-grain-stats");
        const grain = document.createElement("p");
        grain.id = Crop[key] + "-stats";
        setElementInnerHTML(grain, value.stockpile + " " + Crop[key]);
        parent.appendChild(grain);
        const farms = document.getElementById("farms");
        const farmOption = document.createElement("option");
        farmOption.id = Crop[key] + "-farm-option";
        setElementInnerHTML(farmOption, Crop[key]);
        farms.appendChild(farmOption);
        const sellCrops = document.getElementById("crops-sale");
        const cropOption = document.createElement("option");
        cropOption.id = Crop[key] + "-crop-option";
        setElementInnerHTML(cropOption, Crop[key]);
        sellCrops.appendChild(cropOption);
    });
    setIdInnerHTML("people", player.idlePopulation.toString());
    setIdInnerHTML("soldiers", player.army.totalSoldiers.toString());
    selectFarmer();
}
function selectFarmer() {
    setIdInnerHTML("farmers", player.farms.get(Crop[selectedFarm]).totalFarmers + " " + selectedFarm);
}
function updateStats() {
    setIdInnerHTML("gold", player.gold.toString());
    setIdInnerHTML("soldiers", player.army.totalSoldiers.toString());
    selectFarmer();
    setIdInnerHTML("people", player.idlePopulation.toString());
    player.farms.forEach((value, key) => {
        setIdInnerHTML(Crop[key] + "-stats", value.stockpile.toString() + " " + Crop[key]);
        setIdInnerHTML(Crop[key] + "-farm-option", Crop[key]);
        setIdInnerHTML(Crop[key] + "-crop-option", Crop[key]);
    });
    if (player.farms.size > 0)
        player.orderHarvest();
}
function handleHarvest() {
    player.farms.forEach((value, key) => {
        value.playerHarvest(key);
    });
}
function handleAssignFarmer() {
    if (player.idlePopulation > 0) {
        player.idlePopulation--;
        player.farms.get(Crop[selectedFarm]).totalFarmers++;
    }
}
function handleRemoveFarmer() {
    if (player.farms.get(Crop[selectedFarm]).totalFarmers > 0) {
        player.farms.get(Crop[selectedFarm]).totalFarmers--;
        player.idlePopulation++;
    }
}
function handleAssignSoldier() {
    if (player.idlePopulation > 0) {
        player.idlePopulation--;
        player.army.totalSoldiers++;
    }
}
function handleRemoveSoldier() {
    if (player.army.totalSoldiers > 0) {
        player.idlePopulation++;
        player.army.totalSoldiers--;
    }
}
function handleFarmChoice(element) {
    selectedFarm = element.value;
}
function sellCrop() {
    try {
        const sellAmount = document.getElementById("amount");
        const amount = sellAmount.value;
        const cropElement = document.getElementById("crops-sale");
        const selectedCrop = cropElement.value;
        console.log(selectedCrop);
        if (isNaN(Number(amount)))
            return;
        const crop = Crop[selectedCrop];
        if (player.farms.get(crop).stockpile > 0 && parseInt(amount) <= player.farms.get(crop).stockpile) {
            player.gold += parseInt(amount) * cropMarket.get(crop);
            player.farms.get(crop).stockpile -= parseInt(amount);
        }
    }
    catch (err) {
        console.error(err);
    }
}
window.onload = () => {
    window.setInterval(() => {
        timer += tickRate;
        if (timer > visualRate) {
            timer -= visualRate;
            updateStats();
        }
    }, tickRate);
    loadGUI();
};
